"use client"

import AddSubscription from "../add-subscription"

export default function SyntheticV0PageForDeployment() {
  return <AddSubscription />
}