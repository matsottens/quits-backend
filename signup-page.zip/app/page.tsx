"use client"

import SignupPage from "../signup-page"

export default function SyntheticV0PageForDeployment() {
  return <SignupPage />
}