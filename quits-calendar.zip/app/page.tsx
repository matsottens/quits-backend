"use client"

import CalendarPicker from "../calendar-picker"

export default function SyntheticV0PageForDeployment() {
  return <CalendarPicker />
}