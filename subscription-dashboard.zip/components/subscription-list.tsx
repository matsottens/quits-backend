import { MoreVertical } from "lucide-react"

interface Subscription {
  id: string
  name: string
  price: string
  logo: string
}

interface SubscriptionListProps {
  searchQuery: string
}

export default function SubscriptionList({ searchQuery }: SubscriptionListProps) {
  // Sample subscription data
  const subscriptions: Subscription[] = [
    {
      id: "1",
      name: "Volkskrant",
      price: "€22,75",
      logo: "V",
    },
    {
      id: "2",
      name: "Monday",
      price: "€44,95",
      logo: "M",
    },
    {
      id: "3",
      name: "Parool",
      price: "€27,08",
      logo: "P",
    },
    {
      id: "4",
      name: "Trouw",
      price: "€18,95",
      logo: "T",
    },
    {
      id: "5",
      name: "Netflix",
      price: "€13,95",
      logo: "N",
    },
    {
      id: "6",
      name: "Duolingo",
      price: "€8,95",
      logo: "D",
    },
  ]

  // Filter subscriptions based on search query
  const filteredSubscriptions = searchQuery
    ? subscriptions.filter((sub) => sub.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : subscriptions

  return (
    <div className="divide-y divide-gray-200">
      {filteredSubscriptions.map((subscription) => (
        <div key={subscription.id} className="flex items-center justify-between p-4 bg-white">
          <div className="flex items-center">
            <LogoComponent name={subscription.name} logo={subscription.logo} />
            <span className="ml-4 text-xl font-medium">{subscription.name}</span>
          </div>
          <div className="flex items-center">
            <span className="mr-4 text-xl font-medium">{subscription.price}</span>
            <button className="p-1">
              <MoreVertical className="h-6 w-6" />
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}

// Custom component to display subscription logos
function LogoComponent({ name, logo }: { name: string; logo: string }) {
  // Custom logos for specific subscriptions
  switch (name) {
    case "Volkskrant":
      return <div className="w-10 h-10 flex items-center justify-center font-serif text-2xl font-bold">V</div>
    case "Monday":
      return (
        <div className="w-10 h-10 flex items-center">
          <svg viewBox="0 0 24 24" className="w-full h-full">
            <rect x="2" y="6" width="6" height="12" rx="2" fill="#ff3030" />
            <rect x="9" y="6" width="6" height="12" rx="2" fill="#ffba00" />
            <rect x="16" y="6" width="6" height="12" rx="2" fill="#30c566" />
          </svg>
        </div>
      )
    case "Parool":
      return <div className="w-10 h-10 flex items-center justify-center font-serif text-2xl font-bold">P</div>
    case "Trouw":
      return (
        <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[#003b7a] text-white font-bold">
          T
        </div>
      )
    case "Netflix":
      return <div className="w-10 h-10 flex items-center justify-center bg-red-600 text-white font-bold">N</div>
    case "Duolingo":
      return (
        <div className="w-10 h-10 flex items-center justify-center">
          <svg viewBox="0 0 24 24" className="w-full h-full">
            <path
              d="M12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12C22,6.48 17.52,2 12,2Z"
              fill="#58cc02"
            />
            <circle cx="9" cy="9" r="2" fill="white" />
            <circle cx="15" cy="9" r="2" fill="white" />
            <circle cx="9" cy="9" r="1" fill="black" />
            <circle cx="15" cy="9" r="1" fill="black" />
            <path
              d="M12,14C10.5,14 9.2,14.5 8.2,15.4L9.5,17C10.2,16.4 11.1,16 12,16C12.9,16 13.8,16.4 14.5,17L15.8,15.4C14.8,14.5 13.5,14 12,14Z"
              fill="white"
            />
          </svg>
        </div>
      )
    default:
      return <div className="w-10 h-10 flex items-center justify-center bg-gray-200 rounded-full font-bold">{logo}</div>
  }
}

